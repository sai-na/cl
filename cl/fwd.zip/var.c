#include <stdio.h>
void main()
{
	int a , b , c ; 
	c = a + b ;	
	b >= a ;

	}
